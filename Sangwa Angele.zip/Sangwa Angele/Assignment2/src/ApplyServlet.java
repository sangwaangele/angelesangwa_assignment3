import java.io.IOException;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/ApplyServlet")
@MultipartConfig
public class ApplyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
        String fullnames = request.getParameter("fullnames");
        String email = request.getParameter("email");
 
        Part passportPart = request.getPart("passport");
        Part diplomaPart = request.getPart("diploma");

      
        sendConfirmationEmail(fullnames, email);

  
        response.sendRedirect("welcome.html");
    }

    private void sendConfirmationEmail(String fullnames, String recipientEmail) {
        final String senderEmail = "angelesangwa060@gmail.com"; 
        final String senderPassword = "szrs flyr deug egxe"; // 

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getDefaultInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Submission Confirmation");
            message.setText("Dear " + fullnames + ",\n\nThank you for submitting your application.");

            Transport.send(message);

            System.out.println("Confirmation email sent to " + recipientEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
